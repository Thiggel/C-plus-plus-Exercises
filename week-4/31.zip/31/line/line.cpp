#include "line.ih"

Line::Line()
{
    // initialize position as first element
    pos = 0;
}