#include "parser.ih"

Parser::Parser():
d_isIntegral(false)
{
    d_line = Line();
}