#include "calculator/calculator.h"

int main()
{
  // run the calculator program
  Calculator();
}